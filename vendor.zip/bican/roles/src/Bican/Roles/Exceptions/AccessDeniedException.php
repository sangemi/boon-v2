<?php

namespace Bican\Roles\Exceptions;

use Exception;

class AccessDeniedException extends Exception
{
    //
}
