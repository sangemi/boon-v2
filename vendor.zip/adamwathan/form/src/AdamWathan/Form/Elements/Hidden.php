<?php namespace AdamWathan\Form\Elements;

class Hidden extends Input
{
    protected $attributes = [
        'type' => 'hidden',
    ];
}
