<?php

namespace AdamWathan\Form\Elements;

class Email extends Text
{
    protected $attributes = [
        'type' => 'email',
    ];
}
