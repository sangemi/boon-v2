<?php namespace AdamWathan\Form\Elements;

class Password extends Text
{
    protected $attributes = [
        'type' => 'password',
    ];
}
