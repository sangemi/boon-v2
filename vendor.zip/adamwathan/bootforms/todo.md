To Do
===============

- Somehow grouping inline checkboxes/radios into a form-group div
- HTML5 elements like email and date

- Horizontal inline checkbox/radio